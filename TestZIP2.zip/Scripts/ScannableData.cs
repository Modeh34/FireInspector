using UnityEngine;
using TMPro;
using System;

public class ScannableData : MonoBehaviour
{
    /// <summary>
    /// Container class for data the scanner can grab
    /// </summary>
    public string scanName;
    public Texture scanImage;  // Used to update RawImage elements
}
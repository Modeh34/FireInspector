using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Localization.Settings;

public class LocaleSelector : MonoBehaviour
{
    private void Start() { ChangeLocale(PlayerPrefs.GetInt("LocaleKey",0)); }
    private bool active = false;
    public void ChangeLocale(int localeID) {
        if (active == true) { return; }
        StartCoroutine(SetLocale(localeID));
    }
    IEnumerator SetLocale(int _localeID) {
        active = true;
        yield return LocalizationSettings.InitializationOperation;
        LocalizationSettings.SelectedLocale = LocalizationSettings.AvailableLocales.Locales[_localeID];
        PlayerPrefs.SetInt("LocaleKey",_localeID);
        active = false;
    }

    public void Update()
    {
        if (Input.GetKeyDown("1") && !active) { ChangeLocale(0); }
        else if (Input.GetKeyDown("2") && !active) { ChangeLocale(1); }
    }
}

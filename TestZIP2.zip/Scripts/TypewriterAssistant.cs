using UnityEngine;

public class TypewriterAssistant
{
    /// <summary>
    /// Attach this to the canvas holding the text
    /// </summary>
    private void Start()
    {
        TypewriterEffect.Add("Sample");
    }
}

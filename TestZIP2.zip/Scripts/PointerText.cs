using UnityEngine;
using UnityEngine.Events;
using UnityEngine.XR;
using TMPro;
using System.Collections.Generic;
using System.Linq;
using System;
using UnityEngine.UI;

// Code adapted from https://www.youtube.com/watch?v=iEEk0wgFSdY
public class PointerText : MonoBehaviour
{
    [SerializeField]
    private XRNode controllerNode = XRNode.RightHand;

    public InputDevice controller;
    public TMP_Text pointingToText;
    public TMP_Text taggedText;
    public TMP_Text directionText;
    public GameObject graph1;
    public BlinkerAssistant blinkerAssistant;
    public AudioSource source;
    public AudioClip scanSucceedSound;
    public AudioClip scanFailSound;

    private Ray scanRay;
    private RaycastHit hit;
    private Transform objectHit;
    private GameObject scannedObject;
    private string scannedName;
    private List<InputDevice> devices = new List<InputDevice>();
    private bool buttonPressed;

    void Start(){
        taggedText.text = "";
        graph1.SetActive(false);
        scanRay = new Ray(transform.position, -transform.up);
        GetDevice();
    }

    private void GetDevice() {
        InputDevices.GetDevicesAtXRNode(controllerNode, devices);
        controller = devices.FirstOrDefault();
    }
    
    void Update() {
        if (controller == null) { GetDevice(); }

        // Passive scannability check
        scanRay = new Ray(transform.position, -transform.up);
        if (Physics.Raycast(scanRay, out hit)) {
            objectHit = hit.transform;
            if (objectHit.tag=="Scannable") { pointingToText.text = "Scannable"; }
            else { pointingToText.text = "Unscannable"; }
        }
        else { pointingToText.text = "Unscannable"; }
        
        // Firing check
        if (Input.GetMouseButtonDown(0)) { FireScan(); }
        bool buttonValue;
        if (controller.TryGetFeatureValue(CommonUsages.triggerButton, out buttonValue) && buttonValue) {
            FireScan();
            if (!buttonPressed) {
                Debug.Log("trigger is pressed "+buttonValue);
                FireScan();
                buttonPressed = true;
            }
        }
        else if (buttonPressed) {
            Debug.Log("trigger is released "+buttonValue);
            buttonPressed = false;
        }
        directionText.text = "x="+transform.rotation.x.ToString("0.00")+",y="+transform.rotation.y.ToString("0.00");
    }

    public void FireScan() {
        if (Physics.Raycast(scanRay, out hit, 100)) {
            objectHit = hit.transform;
            if (!Physics.Raycast(scanRay, out hit, 100) || objectHit.tag!="Scannable") {
                taggedText.text = "Could not scan";
                blinkerAssistant.BlinkRed();
                AudioSource.PlayClipAtPoint(scanFailSound, transform.position, 1);
            }
            else {
                scannedObject = objectHit.gameObject;
                scannedName = scannedObject.GetComponent<ScannableData>().scanName;

                try { taggedText.text = "Scanned:"+scannedName; }
                catch { taggedText.text = "Scanned:"+objectHit.name; }

                graph1.SetActive(true);
                graph1.GetComponent<RawImage>().texture = scannedObject.GetComponent<ScannableData>().scanImage;

                blinkerAssistant.BlinkGreen();
                AudioSource.PlayClipAtPoint(scanSucceedSound, transform.position, 1);
            }
        }
    }
}

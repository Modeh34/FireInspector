using UnityEngine;
using UnityEngine.UI;
using System.Runtime.CompilerServices;

public class BlinkerAssistant : MonoBehaviour
{
    public GameObject blinkerPanel;
    private float counter;
    private const float MAX_COUNTER = 100;
    private bool isActive;
    private Vector3 scaleStep;

    void Start()
    {
        blinkerPanel.transform.localScale = Vector3.zero;  
        scaleStep = new Vector3(2/MAX_COUNTER, 2/MAX_COUNTER, 2/MAX_COUNTER); 
    }

    void Update()
    {
        if (isActive) {
            if (counter <= MAX_COUNTER/2) { blinkerPanel.transform.localScale += scaleStep; }
            else if (counter > MAX_COUNTER/2) { blinkerPanel.transform.localScale -= scaleStep; }
            counter++;
            if (counter >= MAX_COUNTER) {
                isActive = false;
                counter = 0;
                blinkerPanel.transform.localScale = Vector3.zero;
            }
        }
    }

    public void BlinkRed() {
        if (isActive) { return; }
        isActive = true;
        blinkerPanel.GetComponent<Image>().color = UnityEngine.Color.red;
    }

    public void BlinkGreen() {
        if (isActive) { return; }
        isActive = true;
        blinkerPanel.GetComponent<Image>().color = UnityEngine.Color.green;
    }
}

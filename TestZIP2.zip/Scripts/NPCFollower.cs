using UnityEngine;
using UnityEngine.AI;

// Code used from https://www.sharpcoderblog.com/blog/npc-follow-player-in-unity-3d

public class NPCFollower : MonoBehaviour
{
    public Transform transformToFollow;
    NavMeshAgent agent;

     void Start()
    {
        agent = GetComponent<NavMeshAgent>();
    }
     void Update()
    {
        //Follow the player
        agent.destination = transformToFollow.position;
    }
}

using UnityEngine; 
using Unity.UI; 
using UnityEngine.SceneManagement; 
 
public class SceneSwitch: MonoBehaviour 
{ 
    //function to switch from StartScene to NewScene 
    public void LoadMenu() 
    { 
        SceneManager.LoadScene("Menu"); 
    } 
    //function to switch from NewScene to StartScene 
    public void LoadBasicScene() 
    { 
        SceneManager.LoadScene("BasicScene"); 
    }
    public void LoadSampleScene() 
    { 
        SceneManager.LoadScene("SampleScene"); 
    } 
} 
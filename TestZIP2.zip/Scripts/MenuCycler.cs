using UnityEngine;
using System;
using System.Collections.Generic;

public class MenuCycler : MonoBehaviour
{
    public SceneSwitch sceneManager;
    public GameObject card1;
    public GameObject card2;
    public GameObject card3;
    public GameObject card4;
    private int listIndex = -1;
    
    public void OnClick() {
        listIndex++;
        switch (listIndex)
        {
            case 0:
                card2.SetActive(true);
                card1.SetActive(false);
                break;
            case 1:
                card3.SetActive(true);
                card2.SetActive(false);
                break;
            case 2:
                card4.SetActive(true);
                card3.SetActive(false);
                break;
            default:
                sceneManager.LoadBasicScene();
                break;
        }
    }
}
